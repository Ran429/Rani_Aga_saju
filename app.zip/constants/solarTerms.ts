export const solarTerms = [
    { month: 2, day: 4 },   // 입춘
    { month: 3, day: 6 },   // 경칩
    { month: 4, day: 5 },   // 청명
    { month: 5, day: 5 },   // 입하
    { month: 6, day: 6 },   // 망종
    { month: 7, day: 7 },   // 소서
    { month: 8, day: 7 },   // 입추
    { month: 9, day: 7 },   // 백로
    { month: 10, day: 8 },  // 한로
    { month: 11, day: 7 },  // 입동
    { month: 12, day: 7 },  // 대설
    { month: 1, day: 6 },   // 소한
  ];