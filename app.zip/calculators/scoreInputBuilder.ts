// app/calculators/scoreInputBuilder.ts
import { SajuResultType } from "@/app/types/sajuTypes";
import { ScoreInput } from "./scoreCalculator";

// 사주 점수 계산용 입력 데이터 생성
export function buildScoreInput(result: SajuResultType, name: string): ScoreInput {
  return {
    name,
    ilji_wolji_chung: checkIljiWoljiChung(result),
    pyungwan_count: countTenGod(result, "편관"),
    only_wolji_pyungwan: checkOnlyWoljiPyungwan(result),
    has_all_elements: hasAllFiveElements(result),
    hap_count: result.occurredUnions?.length ?? 0,
    same_element_count: getMaxSameElementCount(result.baseElements),
    same_season: getSameSeason(result),
    wolji_supports_ilgan: checkWoljiSupportsIlgan(result),
    gilshin_count: result.goodGods?.length ?? 0,
    hyungshin_count: countHyungshin(result),
    sibun_positive_count: countSibunPositive(result),
    sibun_negative_count: countSibunNegative(result),
    jaesung: hasTenGod(result, "정재") || hasTenGod(result, "편재"),
    siksang: hasTenGod(result, "식신") || hasTenGod(result, "상관"),
    wonjin: hasWonjin(result),
    cheon_eul_gui_in: hasCheonEulGuiIn(result),
  };
}

// ====================== 개별 체크 함수 ======================

// 일지-월지 충
function checkIljiWoljiChung(result: SajuResultType): boolean {
  return result.occurredConflicts?.some((c: string) => c.includes("일지-월지")) ?? false;
}

// 특정 십성 개수 카운트
function countTenGod(result: SajuResultType, god: string): number {
  return Object.entries(result.baseTenGods).reduce(
    (sum, [key, val]) => (key === god ? sum + val : sum),
    0
  );
}

// 월지에만 편관 1개
function checkOnlyWoljiPyungwan(result: SajuResultType): boolean {
  const monthTenGods = [result.month.tenGodSky, result.month.tenGodGround];
  const count = monthTenGods.filter((g) => g === "편관").length;
  return count === 1 && countTenGod(result, "편관") === 1;
}

// 오행 모두 존재 여부
function hasAllFiveElements(result: SajuResultType): boolean {
  return Object.keys(result.baseElements).filter((e) => result.baseElements[e] > 0).length === 5;
}

// 동일 오행 최댓값
function getMaxSameElementCount(elements: Record<string, number>): number {
  return Math.max(...Object.values(elements));
}

// 계절 일치 여부 (로직은 추후 구현)
function getSameSeason(result: SajuResultType): string | null {
  // TODO: 월지·일지 계절 비교 로직
  return null;
}

// 월지가 일간을 도와주는 구조 여부 (로직은 추후 구현)
function checkWoljiSupportsIlgan(result: SajuResultType): boolean {
  // TODO: 월지 오행이 일간을 생하는지 판별
  return false;
}

// 흉신 개수 세기 (specialGods 중 흉신 분류 로직 구현 필요)
function countHyungshin(result: SajuResultType): number {
  // TODO: 흉신 필터링 로직
  return 0;
}

// 십이운성 긍정 조건 카운트
function countSibunPositive(result: SajuResultType): number {
  return Object.values(result.twelveFortunes).filter((f) =>
    ["장생", "건록", "제왕"].includes(f)
  ).length;
}

// 십이운성 부정 조건 카운트
function countSibunNegative(result: SajuResultType): number {
  return Object.values(result.twelveFortunes).filter((f) =>
    ["쇠", "병", "사", "묘", "절"].includes(f)
  ).length;
}

// 특정 십성 존재 여부
function hasTenGod(result: SajuResultType, god: string): boolean {
  return countTenGod(result, god) > 0;
}

// 원진살 여부
function hasWonjin(result: SajuResultType): boolean {
  return result.specialGods?.some((sg) => sg.name === "원진살") ?? false;
}

// 천을귀인 여부
function hasCheonEulGuiIn(result: SajuResultType): boolean {
  return result.goodGods?.some((gg) => gg.name === "천을귀인") ?? false;
}
